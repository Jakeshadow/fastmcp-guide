#!/usr/bin/env bash
# =============================================================================
# promote-canary.sh — shift nginx canary weight for the FastMCP server.
#
# Usage:
#   ./promote-canary.sh 10        # ~10% traffic to canary  (weight 9:1)
#   ./promote-canary.sh 50        # ~50%                     (weight 1:1)
#   ./promote-canary.sh 100       # 100% to canary
#   ./promote-canary.sh rollback  # restore 100% stable
#
# It copies the chosen upstream config into the active include path, validates
# with `nginx -t`, and reloads ONLY if validation passes. Any failure aborts
# without reloading, leaving the previous config live.
#
# Part of the FastMCP Production Manual (Pro). Adjust the paths below to match
# your nginx layout before use.
# =============================================================================
set -euo pipefail

# --- Configuration (edit to match your host) ---------------------------------
# Directory holding the upstream-canary-*.conf files (this script's dir).
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# Active include path that your main nginx server block `include`s, e.g.:
#   include /etc/nginx/mcp-canary/active.conf;
ACTIVE_CONF="/etc/nginx/mcp-canary/active.conf"
NGINX_BIN="nginx"

usage() {
    echo "Usage: $0 {10|50|100|rollback}" >&2
    exit 2
}

[ $# -eq 1 ] || usage

case "$1" in
    10)       SRC="$SRC_DIR/upstream-canary-10.conf";  LABEL="~10% canary" ;;
    50)       SRC="$SRC_DIR/upstream-canary-50.conf";  LABEL="~50% canary" ;;
    100)      SRC="$SRC_DIR/upstream-canary-100.conf"; LABEL="100% canary" ;;
    rollback) SRC="$SRC_DIR/upstream-canary-rollback.conf"; LABEL="100% stable (rollback)" ;;
    *)        usage ;;
esac

# The rollback config is generated on the fly from the 100 template if missing:
# stable gets all traffic, canary marked down.
if [ "$1" = "rollback" ] && [ ! -f "$SRC" ]; then
    cat > "$SRC" <<'EOF'
upstream mcp_backend {
    server 127.0.0.1:8000;            # stable (100%)
    server 127.0.0.1:8001 down;       # canary marked down
    keepalive 32;
}
location /mcp {
    proxy_pass http://mcp_backend;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_http_version 1.1;
    proxy_set_header Connection "";
    proxy_buffering off;
    proxy_request_buffering off;
    proxy_cache off;
    chunked_transfer_encoding on;
    proxy_read_timeout 600s;
    proxy_pass_header mcp-session-id;
    proxy_pass_header mcp-protocol-version;
}
EOF
fi

if [ ! -f "$SRC" ]; then
    echo "ERROR: source config not found: $SRC" >&2
    exit 1
fi

echo ">> Selecting: $LABEL"
echo ">> Copying $SRC -> $ACTIVE_CONF"
mkdir -p "$(dirname "$ACTIVE_CONF")"

# Back up the current active config so we can restore it if the test fails.
BACKUP=""
if [ -f "$ACTIVE_CONF" ]; then
    BACKUP="${ACTIVE_CONF}.bak.$(date +%s)"
    cp "$ACTIVE_CONF" "$BACKUP"
fi

cp "$SRC" "$ACTIVE_CONF"

echo ">> Validating nginx configuration..."
if ! "$NGINX_BIN" -t; then
    echo "ERROR: nginx -t failed. Restoring previous config and aborting." >&2
    if [ -n "$BACKUP" ]; then
        cp "$BACKUP" "$ACTIVE_CONF"
    else
        rm -f "$ACTIVE_CONF"
    fi
    exit 1
fi

echo ">> Reloading nginx..."
"$NGINX_BIN" -s reload

echo ">> Done: $LABEL is now live."
