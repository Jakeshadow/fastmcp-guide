# Canary Rollout — Kubernetes (replica-ratio)

Part of the **FastMCP Production Manual** Pro asset bundle (Ch6 CI/CD).

This is the **dependency-free** way to do canary on Kubernetes: run two
Deployments behind one Service and shift traffic by adjusting the **replica
ratio** between them.

## How it works

```
                 ┌─────────────────────────┐
   client ─────► │   Service: mcp          │  selector: app=mcp
                 │   (spans both tracks)   │
                 └───────────┬─────────────┘
                  ┌──────────┴───────────┐
                  ▼                      ▼
        Deployment mcp-stable     Deployment mcp-canary
        labels: app=mcp           labels: app=mcp
                track=stable              track=canary
```

The Service selects only `app: mcp`, so its endpoint set is the **union** of
stable + canary pods. kube-proxy load-balances across all ready pods, so the
effective traffic split ≈ the replica ratio:

| Stage | canary replicas | stable replicas | ≈ canary traffic |
|-------|-----------------|-----------------|------------------|
| 1     | 1               | 9               | ~10%             |
| 2     | 5               | 5               | ~50%             |
| 3     | 10              | 0               | 100% (promote)   |

## Files

| File | Purpose |
|------|---------|
| `stable-deployment.yaml` | The stable track (`track: stable`), normally 10 replicas |
| `canary-deployment.yaml` | The canary track (`track: canary`), starts at 0 replicas |
| `service.yaml` | One Service selecting `app: mcp` across both tracks |
| `github-actions-canary.yml` | Staged rollout (10→50→100) with health gates + auto-rollback |

## Usage

```bash
kubectl apply -f stable-deployment.yaml
kubectl apply -f canary-deployment.yaml
kubectl apply -f service.yaml
```

Then trigger the **Canary Rollout (Kubernetes)** workflow with the image tag to
ship. It scales the canary up in stages, gates each stage on `/health`, and on
success promotes the image onto `mcp-stable`. Any failed gate rolls back to
100% stable automatically.

## Limitation & when to upgrade

Replica-ratio splitting is **coarse** — it's only as granular as your replica
counts, assumes similar per-pod capacity, and load-balances per-connection (not
true weighted %). It also can't do header/cookie-based routing or automated
metric analysis.

For **true, fine-grained progressive delivery**, adopt one of:

- **Argo Rollouts** — `Rollout` resource with `setWeight: 10/50/100` steps and
  analysis templates (query Prometheus between steps).
- **Flagger** — automated canary analysis driven by metrics, with a service
  mesh or ingress provider.
- **Istio / Linkerd** — `VirtualService` weighted routing for exact percentages
  and traffic mirroring.

Replace the replica-scaling steps in the workflow with the controller's
weight steps when you move up.

> Replace `ghcr.io/you/mcp-server`, `KUBE_NAMESPACE`, and `secrets.KUBE_CONFIG`
> before use.
