# Grafana Dashboard + Prometheus Alerts — FastMCP

Part of the **FastMCP Production Manual** Pro asset bundle (Ch7 Monitoring &
Alerting).

Prebuilt monitoring for a FastMCP production server: an importable Grafana
dashboard plus Prometheus alerting rules and a scrape/Alertmanager example.

## Files

| File | Purpose |
|------|---------|
| `grafana-dashboard.json` | Importable Grafana dashboard (Grafana 10/11, schemaVersion 39) |
| `prometheus-alerts.yml` | Alerting rules: ServiceDown, HighErrorRate, HighLatencyP95, HighMemory |
| `prometheus-scrape-example.yml` | Scrape config for `/metrics` + Alertmanager→PagerDuty example |

## ⚠️ Read this first — metric names

The dashboard and alerts use the **standard** metric names emitted by the common
Python stack (`prometheus-fastapi-instrumentator` / OpenTelemetry HTTP server
metrics):

| Metric | Used for |
|--------|----------|
| `http_requests_total{handler,method,status}` | request rate, error rate |
| `http_request_duration_seconds_bucket` | p50/p95/p99 latency (histogram) |
| `http_requests_inprogress` | in-flight requests |
| `process_resident_memory_bytes` | memory panel + HighMemory alert |
| `process_cpu_seconds_total` | CPU panel |

**If your server exports different metric names, find-and-replace them** in
`grafana-dashboard.json` and `prometheus-alerts.yml`. Check what your server
actually exposes:

```bash
curl -s https://mcp.yourdomain.com/metrics | grep -E "http_requests_total|http_request_duration_seconds"
```

### Optional custom metrics

Two panels and one (commented) alert use **custom** metrics that the manual's
Ch7 shows you how to instrument:

- `mcp_tool_calls_total{tool,status}` — per-tool call rate & errors
- `mcp_active_sessions` — current MCP sessions

These panels stay **empty until you add the custom instrumentation** in your
server. That's expected — they're scaffolding for when you wire it up.

## Import the dashboard

1. Grafana → **Dashboards → New → Import**
2. Upload `grafana-dashboard.json` (or paste its contents)
3. When prompted, select your **Prometheus** data source for `DS_PROMETHEUS`
4. Click **Import**

The dashboard uses a `${DS_PROMETHEUS}` datasource variable, so it binds to
whatever Prometheus source you pick at import time.

## Load the alert rules

1. Copy `prometheus-alerts.yml` to your Prometheus rules directory, e.g.
   `/etc/prometheus/rules/prometheus-alerts.yml`
2. Reference it in `prometheus.yml`:
   ```yaml
   rule_files:
     - /etc/prometheus/rules/prometheus-alerts.yml
   ```
3. Reload Prometheus (`kill -HUP` or `/-/reload` endpoint) and confirm under
   **Status → Rules**.

## Wire alerts to PagerDuty

`prometheus-scrape-example.yml` shows the scrape job and the Alertmanager
target. The PagerDuty routing itself lives in **alertmanager.yml** — the file
includes a commented `route` / `receivers` example. Drop in your PagerDuty
integration key and alerts tagged `severity=critical` / `severity=warning` will
route accordingly.

## Alerts at a glance

| Alert | Condition | Severity |
|-------|-----------|----------|
| ServiceDown | `up{job="mcp"} == 0` for 1m | critical |
| HighErrorRate | 5xx ratio > 5% for 5m | critical |
| HighLatencyP95 | p95 > 1s for 10m | warning |
| HighMemory | RSS > 512MiB for 10m | warning |
| HighToolErrorRate *(optional)* | tool error ratio > 10% | warning |

> Replace `mcp.yourdomain.com` and the PagerDuty key before use.
