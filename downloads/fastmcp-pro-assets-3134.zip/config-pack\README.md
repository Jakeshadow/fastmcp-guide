# FastMCP Production — Config Template Pack

Drop-in, ready-to-adapt configuration files for deploying a **FastMCP** server
to production. Everything here is derived from the **FastMCP Production Manual**
(Chapters 2, 4, 5, 6). These are *templates* — they contain placeholders you
**must** replace before use.

> ⚠️ **READ FIRST — replace all placeholder domains, tokens, and registry paths
> before deploying. NEVER commit real secrets** (API keys, OAuth client
> secrets, signing keys, DB/Redis passwords). Secrets belong in Docker secrets
> or a vault, injected at runtime.

---

## What's in the pack

```
config-pack/
├── nginx/
│   └── mcp-server.conf         # Ch2: reverse proxy for Streamable HTTP
├── docker/
│   ├── Dockerfile              # Ch4: multi-stage, non-root, tini, healthcheck
│   ├── docker-compose.yml      # Ch4/Ch5: full single-host stack
│   └── .env.example            # non-secret env template
├── k8s/                        # L4 starting templates (adapt before use)
│   ├── deployment.yaml         # 3 replicas, probes, hardened securityContext
│   ├── service.yaml            # ClusterIP 80 -> 8000
│   ├── configmap.yaml          # non-secret env
│   └── ingress.yaml            # nginx ingress + streaming annotations + TLS
├── ci/
│   └── github-actions-deploy.yml  # Ch6: test -> build -> deploy-staging
└── README.md                   # this file
```

### File-by-file

| File | Source | Purpose |
|------|--------|---------|
| `nginx/mcp-server.conf` | Ch2 | TLS termination + rate limiting + the critical `/mcp` streaming block (buffering off, long read timeout, session-id passthrough) + CORS whitelist. |
| `docker/Dockerfile` | Ch4 | Multi-stage `python:3.12-slim` build, non-root `mcp` user, `tini` as PID 1, `HEALTHCHECK` against `/health`, uvicorn with uvloop + httptools. |
| `docker/docker-compose.yml` | Ch4 + Ch5 #7 | `mcp` + `nginx` + `redis` + `certbot`; resource limits, log rotation, graceful shutdown, and container hardening (`no-new-privileges`, `cap_drop: ALL`). |
| `docker/.env.example` | — | Non-secret config you copy to `.env`. |
| `k8s/*.yaml` | Ch4 | **L4 starting point.** Deployment with liveness (`/liveness`) + readiness (`/health`) probes, read-only rootfs + `emptyDir` `/tmp`, ConfigMap/Secret refs, Service, and an Ingress carrying the streaming annotations. |
| `ci/github-actions-deploy.yml` | Ch6 | Lint/type/test with coverage gate, multi-arch buildx push to GHCR, Trivy CRITICAL/HIGH gate, SSH rolling deploy + smoke tests. |

---

## Placeholders to replace

| Placeholder | Replace with |
|-------------|--------------|
| `mcp.yourdomain.com` | Your real MCP host |
| `*.yourdomain.com` / `app.yourdomain.com` | Your real (wildcard) domain |
| `staging.yourdomain.com` | Your staging host |
| `ghcr.io/you/mcp-server` | Your container registry path |
| `<YOUR_TOKEN>` | Any token referenced in your environment |
| `<YOUR_CLUSTER_ISSUER>` | Your cert-manager `ClusterIssuer` name |
| GitHub secrets (`STAGING_HOST`, `STAGING_USER`, `STAGING_SSH_KEY`) | Configure in repo settings |

---

## Deploy order

Pick the tier that matches your scale (per the manual's L2–L4 model).

### L2 / L3 — single host with Docker Compose

1. Copy the env template and edit it:
   ```bash
   cp docker/.env.example docker/.env
   # edit docker/.env (non-secrets only)
   ```
2. Provide real secrets via Docker secrets / vault (not `.env`).
3. Replace domains in `nginx/mcp-server.conf`.
4. Obtain TLS certs (certbot service handles renewal; bootstrap the first cert).
5. Bring up the stack:
   ```bash
   cd docker
   docker compose up -d --build
   ```
6. Verify:
   ```bash
   curl -fsS https://mcp.yourdomain.com/health
   ```

### L4 — Kubernetes

> K8s manifests are **starting templates** — adapt replicas, resources, probes,
> and secret wiring to your cluster.

1. Create the non-secret config and the Secret:
   ```bash
   kubectl apply -f k8s/configmap.yaml
   kubectl create secret generic mcp-secrets --from-literal=signing-key=<YOUR_TOKEN>
   ```
2. Set the cert-manager issuer + domain in `k8s/ingress.yaml`.
3. Apply the rest:
   ```bash
   kubectl apply -f k8s/deployment.yaml -f k8s/service.yaml -f k8s/ingress.yaml
   ```

### CI/CD

Drop `ci/github-actions-deploy.yml` into `.github/workflows/`, configure the
referenced repo secrets, and push to `main`.

---

## Streaming gotchas (don't break these)

FastMCP uses **Streamable HTTP** (SSE-style streaming). The following must stay
as configured or streaming will break:

- nginx `/mcp`: `proxy_buffering off;`, `proxy_cache off;`,
  `proxy_request_buffering off;`, `chunked_transfer_encoding on;`,
  `proxy_read_timeout 600s;`, and pass-through of `mcp-session-id` /
  `mcp-protocol-version`.
- K8s ingress: `proxy-buffering: "off"` and `proxy-read-timeout: "600"`.

---

**Again: replace every placeholder, and never commit real secrets.**
